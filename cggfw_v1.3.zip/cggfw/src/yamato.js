
var yamato1=new Array(
0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,
0,1,0,1,1,1,0,1,0,0,0,0,0,0,0,0,
0,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,
0,1,0,1,0,1,0,0,0,0,1,1,1,1,0,0,
0,1,0,1,0,1,0,0,0,0,0,0,0,0,1,0,
0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,
0,1,0,0,1,0,0,0,1,1,1,1,0,0,1,0,
0,0,1,0,1,0,0,0,0,0,0,1,1,1,0,0,
0,0,1,0,0,0,0,1,1,1,1,0,0,0,0,0,
0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0
);
var yamato2=new Array();
var chrctx=new Array(0,16,10);
var d=1;
var yx=80;
var yy=50;
function init(){
for(var i=0;i<=9;i++){
for(var j=0;j<=15;j++){
yamato2[i*16+j]=yamato1[i*16+15-j];
}
}
color(1);
putc(yamato1,chrctx,yx,yy);
color(6);
for(var i=0;i<=9;i++){
put(chrname("fill"),i,11);
}
settimer(1000);
}
function keyin(keychr){
}
function routine(){
beep(1);
cls();
color(1);
var d=Math.floor(Math.random()*2)+1;
var r1=Math.floor(Math.random()*3);
var r2=Math.floor(Math.random()*3);
var hadou=Math.floor(Math.random()*5);
if(r1==1 && yx>=16){yx-=8;}
if(r1==2 && yx<=96){yx+=8;}
if(r2==1 && yy>=10){yy-=5;}
if(r2==2 && yy<=80){yy+=5;}
if(d==1){putc(yamato1,chrctx,yx,yy);}
if(d==2){putc(yamato2,chrctx,yx,yy);}
if(hadou==1){
 beep(0);
 color(6);
 if(d==1){
  for(var i=0;i<=yx/8-1;i++){
   put(chrname("fill"),i,yy/5+1);
  }
 }
 if(d==2){
  for(var i=yx/8+2;i<=19;i++){
  put(chrname("fill"),i,yy/5+1);
  }
 }
}
}