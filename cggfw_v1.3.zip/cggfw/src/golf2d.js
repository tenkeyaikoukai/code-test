

var m1=new Array(0,0,0,0,1,1,1,1,0,0,2,2,2,2,0,3,0,0,0,0,0);
var curx=20;
var cury=80;
var x=20;
var y=20;
var bx=5;
var by=16;
var num,r;
function init(){
play();

}
function play(){

draw();

}
function next(){

draw();

}
function draw(){

cls();
for ( i =0 ; i<= 19 ;i++){
if(m1[i]==0){color(4);put(chrname("fill"),i,18);}
if(m1[i]==1){color(5);put(chrname("wave"),i,18);}
if(m1[i]==2){color(6);put(chrname("equal"),i,18);}
if(m1[i]==3){color(7);put(chrname("flag"),i,17);color(4);put(chrname("fill"),i,18);}

// tree
//if(m[i*x+j]==3){color(7);put(chrname("flag"),j,i);}
x=15;y=11
color(4);
put(chr5,x+1,y);
put(chr4,x+2,y);
put(chr5,x+1,y+1);
put(chr3,x+2,y+1);
put(chr3,x+3,y+1);
put(chr4,x+4,y+1);
color(2);
put(chri,x+1,y+2);
put(chri,x+1,y+4);
put(chri,x+1,y+5);
put(chri,x+1,y+3);
put(chri,x+2,y+3);
put(chri,x+2,y+4);
put(chri,x+2,y+5);
put(chri,x+2,y+2);

}

   color(7);
   put(chrname("circle"),bx,by);

}
  function keyin(){
  document.getElementById("msgwin").innerHTML="";
  var temp=m[by*x+bx];
  var bx2=bx;var by2=by;
   if(event.keyCode==39 & bx<19){bx++;}
   if(event.keyCode==37 & bx>0){bx--;}
   if(event.keyCode==40 & by<19){by++;}
   if(event.keyCode==38 & by>0){by--;}
   if(m[by*x+bx]!=3){
   draw();
   }else{document.getElementById("msgwin").innerHTML="You can not go this direction";bx=bx2;by=by2}   
if(m[by*x+bx]==4){document.getElementById("msgwin").innerHTML="HOLE IN!";}
if(m[by*x+bx]==2){document.getElementById("msgwin").innerHTML="bunker";}
  } 
 
function routine(){
}
