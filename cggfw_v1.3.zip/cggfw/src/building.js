
function init(){
cls();
color(2);

var x,y,i1,i,j;
for(i1=3;i1<=18;i1+=3){
for(j=0;j<=19;j++){
put(chrname("brick"),j,i1);
}
}

x=3;y=3;
putladder(x,y);
y=3;x=10;
putladder(x,y);
y=6;x=17;
putladder(x,y);
y=9;x=6;
putladder(x,y);
}
function keyin(keycode){
}
function routine(){

}

function putladder(px,py){
color(7);
var i;
for(i=py;i<=py+2;i++){
put(chrh,px,i);
}
}
