var mx,my;
var d=1;
var mtx=new Array();
var currentnum=1;
var sc=0;
var gameflag=1;
function init(){

for(i=0;i<=19;i++){
for(j=0;j<=19;j++){
mtx[i*20+j]=0;
}
}
for(i=1;i<=10;i++){
var r1,r2;
var flag=0;
while(flag==0){
r1=Math.floor(Math.random()*17)+1;
r2=Math.floor(Math.random()*17)+1;

//11-19:number 20:my address

if(mtx[r2*20+r1]==0){mtx[r2*20+r1]=10+i;flag=1;}
}
}
mx=r1;my=r2;
}

function routine(){

mtx[my*20+mx]=1;

//up:1 and clockwork

if(d==1){my--;}
if(d==2){mx++;}
if(d==3){my++;}
if(d==4){mx--;}
if(mtx[my*20+mx]>10 && mtx[my*20+mx]!=currentnum+10 || mtx[my*20+mx]==1 || mx<0 || mx>19 || my<0 || my>19){
gameflag=2;
cleartimer();
}
if(mtx[my*20+mx]==currentnum+10){sc++;currentnum++;}
if(currentnum>=10){cleartimer();gameflag=3;}
draw();
}

function keyin(keycode){
if(keycode=="up"){d=1;}
if(keycode=="right"){d=2;}
if(keycode=="down"){d=3;}
if(keycode=="left"){d=4;}
}
function draw(){
cls();
for(i=0;i<=19;i++){
for(j=0;j<=19;j++){
if(mtx[i*20+j]==1){color(4);put(chrname("fill"),j,i);}
if(mtx[i*20+j]==11){color(6);put(chrnum1,j,i);}
if(mtx[i*20+j]==12){color(6);put(chrnum2,j,i);}
if(mtx[i*20+j]==13){color(6);put(chrnum3,j,i);}
if(mtx[i*20+j]==14){color(6);put(chrnum4,j,i);}
if(mtx[i*20+j]==15){color(6);put(chrnum5,j,i);}
if(mtx[i*20+j]==16){color(6);put(chrnum6,j,i);}
if(mtx[i*20+j]==17){color(6);put(chrnum7,j,i);}
if(mtx[i*20+j]==18){color(6);put(chrnum8,j,i);}
if(mtx[i*20+j]==19){color(6);put(chrnum9,j,i);}
if(i==my && j==mx){color(7);put(chrname("circle"),j,i);}
}
}
color(7);
if(gameflag==2){println("* * Game Over * *");}
if(gameflag==3){println("GAME CLEAR!");}
}