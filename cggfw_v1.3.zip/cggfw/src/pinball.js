
var ttx1=3;
var tty1=4;
var ttx2=8;
var tty2=6;
var ttf1=0;
var ttf2=0;
var dtx1=4;
var dty1=1;
var dtf1=0;
var dtx2=6;
var dty2=1;
var dtf2=0;
var dtx3=8;
var dty3=1;
var dtf3=0;
var ct=0;
var bx=6;
var by=15;
var dx=-1;
var dy=-1;
var mx=4;
var sc=0;
function init(){

draw();
settimer(100);

}

function routine(){
cls();
if(ttf1==1){ttf1=0;}
if(ttf2==1){ttf2=0;}
if(dx==-1 && bx<=1){dx=1;}
if(dx==1 && bx>=11){dx=-1;}
if(dy==-1 && by<=1){dy=1;}
//if(dy==1 && by>=17){dy=-1;}
bx+=dx;
by+=dy;
if(by==17 && dy==1){
if((mx-bx)>=-2 &&(mx-bx)<=2){dy=-1;}
}
if((bx>=ttx1 && bx<=ttx1+2) && (by>=tty1 && by<=tty1+2)){
sc++;beep(0);
ttf1=1;
dx=-dx;dy=-dy;
}
/*
if((bx>=ttx2 && bx<=ttx2+2) && (by>=tty2 && by<=tty2+2)){
sc++;beep(0);
ttf2=1;
dx=-dx;dy=-dy;
}
*/
if(bx==dtx1 && by==dty1 && dtf1==0){dtf1=1;sc++;beep(0);}
if(bx==dtx2 && by==dty2 && dtf2==0){dtf2=1;sc++;beep(0);}
if(bx==dtx3 && by==dty3 && dtf3==0){dtf3=1;sc++;beep(0);}

if(dtf1==1 && dtf2==1 && dtf3==1){sc+=10;dtf1=0;dtf2=0;dtf3=0;}
if(by>=19){cleartimer();}
draw();
ct++;
var r;
if(ct>=10){
r=Math.floor(Math.random()*3);
if(r==1 && ttx1>=2){ttx1--;}
if(r==2 && ttx1<=7){ttx1++;}
r=Math.floor(Math.random()*3);
if(r==1 && tty1>=3){tty1--;}
if(r==2 && tty1<=7){tty1++;}
r=Math.floor(Math.random()*3);
if(r==1 && ttx2>=6){ttx2--;}
if(r==2 && ttx2<=7){ttx2++;}
r=Math.floor(Math.random()*3);
if(r==1 && tty2>=3){tty2--;}
if(r==2 && tty2<=7){tty2++;}
ct=0;
}

}
function draw(){
color(7);
put(chrs,15,5);
put(chrc,16,5);
put(chro,17,5);
put(chrr,18,5);
put(chre,19,5);
color(7);
putscore();


color(7);
put(chrname("circle"),bx,by);
for(i=0;i<=2;i++){
put(chrname("equal"),mx+i,18);
}
for(i=0;i<=19;i++){
put(chrname("fill"),0,i);
put(chrname("fill"),12,i);
}
for(i=0;i<=11;i++){
put(chrname("fill"),i,0);
put(chrname("fill"),i,19);
}
putobjects();
}
function keyin(keycode){
if(keycode=="left" && mx>=2){mx--;}
if(keycode=="right" && mx<=7){mx++;}
}

function putobjects(){
var arg1,arg2;
arg1=ttx1;arg2=tty1;
puttt(arg1,arg2,ttf1);
/*
arg1=ttx2;arg2=tty2;
puttt(arg1,arg2,ttf2);
*/
if(dtf1==1){put(chrname("equal"),dtx1,dty1);}
else{put(chrname("block"),dtx1,dty1);}
if(dtf2==1){put(chrname("equal"),dtx2,dty2);}
else{put(chrname("block"),dtx2,dty2);}
if(dtf3==1){put(chrname("equal"),dtx3,dty3);}
else{put(chrname("block"),dtx3,dty3);}

}
function puttt(x,y,f){
if(f==0){
put(chrname("block"),x+1,y);
put(chrname("block"),x+2,y);
put(chrname("block"),x,y+1);
put(chrname("block"),x,y+2);
put(chrname("block"),x+3,y+1);
put(chrname("block"),x+3,y+2);
put(chrname("block"),x+1,y+3);
put(chrname("block"),x+2,y+3);
}else{
put(chrname("block"),x+1,y+1);
put(chrname("block"),x+2,y+1);
put(chrname("block"),x+1,y+2);
put(chrname("block"),x+2,y+2);
}
}

function putscore(){
var cursc,modsc;
modsc=sc%10;
putnumchr(modsc,19,7);
cursc=Math.floor(sc/10);
modsc=cursc%10;
putnumchr(modsc,18,7);
cursc=Math.floor(cursc/10);
modsc=cursc%10;
putnumchr(modsc,17,7);
}
function putnumchr(num,x,y){
if(num==0){put(chrnum0,x,y);}
if(num==1){put(chrnum1,x,y);}
if(num==2){put(chrnum2,x,y);}
if(num==3){put(chrnum3,x,y);}
if(num==4){put(chrnum4,x,y);}
if(num==5){put(chrnum5,x,y);}
if(num==6){put(chrnum6,x,y);}
if(num==7){put(chrnum7,x,y);}
if(num==8){put(chrnum8,x,y);}
if(num==9){put(chrnum9,x,y);}
}
