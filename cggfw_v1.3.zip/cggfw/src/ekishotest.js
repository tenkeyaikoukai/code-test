var mc=new Array(
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,
0,0,0,3,0,0,0,0,0,2,2,0,0,1,4,1,1,0,0,0,
0,0,0,0,0,0,0,0,2,2,0,0,0,1,1,1,0,0,0,0,
0,0,3,0,3,0,0,0,0,0,0,1,0,0,0,0,2,2,0,0,
0,0,0,0,0,0,3,0,0,0,1,1,1,0,0,2,2,0,0,0,
0,0,3,0,3,0,0,0,0,0,1,1,1,1,0,2,0,0,0,0,
0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,
0,0,3,0,3,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,
0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,3,0,0,0,
0,0,0,0,0,1,1,1,1,0,0,0,3,0,0,0,0,0,3,0,
0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,1,1,1,1,0,0,0,3,0,0,0,3,0,0,0,0,0,
0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
);

var chr1=new Array(
0,0,1,1,1,1,0,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,0,1,1,1,1,0,0
);
var chr2=new Array(
0,0,1,0,0,1,0,0,
0,1,1,1,1,1,1,0,
0,1,1,1,1,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0
);
var chr3=new Array(
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
);
var chr4=new Array(
1,0,0,0,0,0,0,0,
1,1,1,0,0,0,0,0,
1,1,1,1,1,0,0,0,
1,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,1
);

var chr5=new Array(
0,0,0,0,0,0,0,1,
0,0,0,0,0,1,1,1,
0,0,0,1,1,1,1,1,
0,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
);
var chr6=new Array(
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,1,1,
0,0,0,0,0,0,0,0
);
var chr7=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chr8=new Array(
0,0,1,0,0,1,0,0,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0
);
var pcg1=new Array(
0,0,0,0,0,0,0,0,
0,0,1,0,0,1,0,0,
1,1,1,0,0,1,1,1,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0,
0,0,1,0,0,1,0,0,
0,0,1,1,1,1,0,0,
1,1,1,0,0,1,1,1,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0
);
var pcg2=new Array(
0,0,1,1,1,1,0,0,
0,1,0,0,0,0,1,0,
1,0,0,1,1,0,0,1,
1,0,1,0,0,1,0,1,
1,0,1,0,0,0,0,1,
1,0,1,0,1,1,0,1,
1,0,1,0,0,1,0,1,
1,0,0,1,1,0,0,1,
0,1,0,0,0,0,1,0,
0,0,1,1,1,1,0,0
);
var m=new Array();
var m2=new Array();
var curx=20;
var cury=80;
var mc,sc,x,y,k,f,i,j,r,l,counter,getcounter,chaincounter,chainflag;
var clck=new Audio("pingpong1.mp3")
var beep=new Audio("beep.mp3");
var num=50;//�G�o���p�x�F�������ق��������Bdefault=30

var chrctx=new Array(0,8,10);
function init(){
play();

}
function play(){
for(i = 0 ;i<= 9 ;i++){
for( j = 0 ; j<=19 ;j++){
m[i*20+j] = 0;
}
} 
for ( i = 0 ; i<= 19 ;i++){
r = Math.floor(Math.random() * 10) + 1;
if ( r == 1 ) { m[1*20 +i] = 1;}
else { m[i*20+ 1] = 0;}
}
sc = 0 ;
x = 10;
y = 8;
counter=0;
chaincounter=0;
chainflag=0;
k=1;
m[y*20+x] = 3;
draw();
sc = sc + 1;


draw();


}
function next(){

draw();

}
function draw(){

ctx.fillStyle="rgb(100,100,100)";
ctx.fillRect(0,0,640,400);

for ( i =0 ; i<= 19 ;i++){
for ( j = 0 ; j<=19 ; j++){
if(mc[i*20+j]==1){ctx.fillStyle="rgb(100,50,0)";put(chr2,chrctx,j*8,i*5);}
if(mc[i*20+j]==2 || mc[i*20+j]==3){ctx.fillStyle="rgb(0,100,0)";put(chr7,chrctx,j*8,i*5);}
}
}

ctx.fillStyle="rgb(255,255,0)";
for ( i =0 ; i<= 19 ;i++){
for ( j = 0 ; j<=19 ; j++){
if(m[i*20+j]==1){ctx.fillStyle="rgb(0,0,0)";put(pcg1,chrctx,j*8,i*10);}
if(m[i*20+j]==2){ctx.fillStyle="rgb(0,0,0)";put(pcg2,chrctx,j*8,i*10);}
if(m[i*20+j]==3){ctx.fillStyle="rgb(0,0,0)";put(pcg1,chrctx,j*8,i*10);}
}
}

}
function keyin(){
if ( event.keyCode == 37 & x >= 1 ) { x = x - 1 ;}
if ( event.keyCode == 39 & x < 19 ){ x = x + 1 ;}
}
function schroll(){
clck.play();
for ( i = 0 ; i<= 19 ; i++){
 r = Math.floor(Math.random() * num + 1);
 if ( r == 1 ){ m[1*20+i] = 1;} else {m[1*20+i] = 0;}
}
if (counter==20){
 r = Math.floor(Math.random() * 20);
m[1*20+r] = 2;}
for (i=8 ; i>=0 ;i--){
 for (j = 0 ;j<=19 ;j++){
  m[(i+1)*20+j] = m[i*20+j];
 }
}  
if (m[y*20+x] == 1){clearInterval(ti);disp.innerHTML="GAME OVER";mssg.innerHTML="";
}
if (m[y*20+x]==2 & chaincounter<=1){mssg.innerHTML="GET!";sc=sc+100;counter=0;chainflag=1;chaincounter=chaincounter+1;beep.play();}
if (m[y*20+x]==2 & chaincounter>=2){mssg.innerHTML=chaincounter+" chain!";sc=sc+100*chaincounter;chainflag=1;chaincounter=chaincounter+1;counter=0;beep.play();}
if(m[y*20+x]!=1 & m[y*20+x]!=2){m[y*20+x] = 3;
draw(); 
sc=sc+1;
counter=counter+1;
disp.innerHTML="SCORE "+sc;
if(counter==25 & chainflag==0){chaincounter=0;counter=0;}
if(counter==25 & chainflag==1){chainflag=0;counter=0;}
}




}
function routine(){
schroll();
}
