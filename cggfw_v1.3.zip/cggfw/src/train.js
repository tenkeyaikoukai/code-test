
var x=-5;
var sx=new Array(0,-1,-3);
var sy=new Array(15,14,14);
var sx0=new Array(0,-1,-3);
var sy0=new Array(15,14,14);
function init(){
settimer(300);

var i,j;
color(7);
for(i=0;i<=19;i++){
put(chrname("sharp"),i,17);
}
}

function routine(){
beep(1);
var i,j;
color(7);
put(chrname("se"),5,5);
put(chrname("sw"),6,5);
color(5);
put(chrname("se"),4,6);
put(chrname("sw"),7,6);
put(chrname("fill"),5,6);
put(chrname("fill"),6,6);
color(6);
put(chrname("circle"),3,3);
color(0);
for(i=x;i<=x+5;i++){
put(chrname("fill"),i,16);
}
x++;
if(x>20){x=-5;sx[0]=0;sx[1]=-1;sx[2]=-3;sy[0]=15;sy[1]=14;sy[2]=14;}
color(1);
put(chrname("block"),x,16);
put(chrname("block"),x+1,16);
put(chrname("block"),x+2,16);
put(chrname("block"),x+3,16);
put(chrname("block"),x+4,16);
put(chrname("sw"),x+5,16);

for(i=0;i<=2;i++){
if(sy[i]==15){color(0);put(chrname("circle"),sx[i],sy[i]);sy[i]=14;}
if(sx[i]<=x){color(0);put(chrname("circle"),sx[i],sy[i]);sx[i]=x+5;sy[i]=15;}
color(7);
put(chrname("circle"),sx[i],sy[i]);
}

}