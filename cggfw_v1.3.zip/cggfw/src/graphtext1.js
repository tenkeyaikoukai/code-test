


function init(){

color(7);
put(chrn,1,5);
put(chru,2,5);
put(chrm,3,5);
put(chrb,4,5);
put(chre,5,5);
put(chrr,6,5);
put(chrs,7,5);
color(6);
put(chrnum0,1,7);
put(chrnum1,2,7);
put(chrnum2,3,7);
put(chrnum3,4,7);
put(chrnum4,5,7);
//put(chra,6,7);
//put(chrr,7,7);
//put(chrs,8,7);
color(5);
put(chrnum5,1,9);
put(chrnum6,2,9);
put(chrnum7,3,9);
put(chrnum8,4,9);
put(chrnum9,5,9);

}

function routine(){

}
