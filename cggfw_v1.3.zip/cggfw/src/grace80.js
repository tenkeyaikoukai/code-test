
var m=new Array();
var m2=new Array();
var curx=20;
var cury=80;
var mc,sc,x,y,k,f,i,j,r,l,counter,getcounter,chaincounter,chainflag;
var clck=new Audio("cggfw/audio/pingpong1.mp3");
var alerm=new Audio("cggfw/audio/beep.mp3");

var num=50;//�G�o���p�x�F�������ق��������Bdefault=30

var chrctx=new Array(0,8,5);
function init(){


play();
settimer(300);
}
function play(){
for(i = 0 ;i<= 19 ;i++){
for( j = 0 ; j<=19 ;j++){
m[i*20+j] = 0;
}
} 
for ( i = 0 ; i<= 19 ;i++){
r = Math.floor(Math.random() * 10) + 1;
if ( r == 1 ) { m[1*20 +i] = 1;}
else { m[i*20+ 1] = 0;}
}
sc = 0 ;
x = 10;
y = 18;
counter=0;
chaincounter=0;
chainflag=0;
k=1;
m[y*20+x] = 3;
draw();
sc = sc + 1;


draw();


}
function next(){

draw();

}
function draw(){
cls();
for ( i =0 ; i<= 19 ;i++){
for ( j = 0 ; j<=19 ; j++){
if(m[i*20+j]==1){color(4);;put(chr8,j,i);}
if(m[i*20+j]==2){color(6);put(chr1,j,i);}
if(m[i*20+j]==3){color(7);put(chr7,j,i);}
}
}

}
function keyin(keychr){
if ( keychr=="left" & x >= 1 ) { x = x - 1 ;}
if ( keychr=="right" & x < 19 ){ x = x + 1 ;}
}
function schroll(){
beep(1);
for ( i = 0 ; i<= 19 ; i++){
 r = Math.floor(Math.random() * num + 1);
 if ( r == 1 ){ m[1*20+i] = 1;} else {m[1*20+i] = 0;}
}
if (counter==20){
 r = Math.floor(Math.random() * 20);
m[1*20+r] = 2;}
for (i=18 ; i>=0 ;i--){
 for (j = 0 ;j<=19 ;j++){
  m[(i+1)*20+j] = m[i*20+j];
 }
}  
if (m[y*20+x] == 1){cleartimer();disp.innerHTML="GAME OVER";mssg.innerHTML="";
}
if (m[y*20+x]==2 & chaincounter<=1){mssg.innerHTML="GET!";sc=sc+100;counter=0;chainflag=1;chaincounter=chaincounter+1;beep(0);}
if (m[y*20+x]==2 & chaincounter>=2){mssg.innerHTML=chaincounter+" chain!";sc=sc+100*chaincounter;chainflag=1;chaincounter=chaincounter+1;counter=0;beep(0);}
if(m[y*20+x]!=1 & m[y*20+x]!=2){m[y*20+x] = 3;
draw(); 
sc=sc+1;
counter=counter+1;
disp.innerHTML="SCORE "+sc;
if(counter==25 & chainflag==0){chaincounter=0;counter=0;}
if(counter==25 & chainflag==1){chainflag=0;counter=0;}
}




}
function routine(){
schroll();
}
