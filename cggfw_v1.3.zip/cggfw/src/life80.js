
var m=new Array();
var m2=new Array();
var curx=20;
var cury=80;
var x=20;
var y=20;
var num,r;

function init(){
settimer(500);
play();

}
function play(){
var i,j;
for(i = 0 ;i<= y-1 ;i++){
for( j = 0 ; j<=x-1 ;j++){
m[i*x+j] = 0;
}
} 
for(i = 0 ;i<= y-1 ;i++){
for( j = 0 ; j<=x-1 ;j++){
m2[i*x+j] = 0;
}
} 
for (i=0;i<=y-1;i++){
for ( j = 0 ; j<= x-1 ;j++){
r = Math.floor(Math.random() * 5) + 1;
if ( r == 1 ) { m[i*x +j] = 1;}
else { m[i*x+ j] = 0;}
}
}
draw();

}
function next(){
var i,j;
for (i=0;i<=y-1;i++){
for (j=0;j<=x-1;j++){
num=0;
if(m[(i-1)*x+j-1]==1){num=num+1;}
if(m[(i-1)*x+j]==1){num=num+1;}
if(m[(i-1)*x+j+1]==1){num=num+1;}
if(m[i*x+j-1]==1){num=num+1;}
if(m[i*x+j+1]==1){num=num+1;}
if(m[(i+1)*x+j-1]==1){num=num+1;}
if(m[(i+1)*x+j]==1){num=num+1;}
if(m[(i+1)*x+j+1]==1){num=num+1;}
if(m[i*x+j]==1 & (num==2 | num==3)){m2[i*x+j]=1;}
if(m[i*x+j]==1 & (num<2 | num>3)){m2[i*x+j]=0;}
if(m[i*x+j]!=1 & num==3){m2[i*x+j]=1;}
if(m[i*x+j]!=1 & num!=3){m2[i*x+j]=0;}
}
}
for (i=0;i<=y-1;i++){
for (j=0;j<=x-1;j++){
m[i*x+j]=m2[i*x+j];
}
}

draw();

}
function draw(){
beep(1);
var i,j;
cls();
color(3);
for ( i =0 ; i<= y-1 ;i++){
for ( j = 0 ; j<=x-1 ; j++){
if(m[i*x+j]==1){put(chrname("heart"),j,i);}
}
}

}

function routine(){
next();
}

