window.onload=(function(){
ctx=document.getElementById("cvs").getContext("2d");
init();
ti=setInterval("routine();",100);
});
function put(chr,chrctx,cx,cy){
var i,j;
//ctx.fillStyle="rgb(255,255,255)";
for(i=0;i<=chrctx[2]-1;i++){
for(j=0;j<=chrctx[1]-1;j++){
if(chr[i*chrctx[1]+j]==1){
ctx.fillRect((cx+j)*4,(cy+i)*4,4,4);
}
}
}
}
