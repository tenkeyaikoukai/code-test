
var m1=new Array(0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0);
var r;
var x=10;
var px,py;
var sc=0;
function init(){
settimer(300);
draw();
px=Math.floor(Math.random()*17)+1;
py=0;
}
function draw(){
cls();
for ( i =0 ; i<= 19 ;i++){
if(i<=x || i>=x+4){r=Math.floor(Math.random()*2)+16;}
if(m1[i]==0){color(5);put(chrname("wave"),i,r);}
if(m1[i]==1){color(2);put(chrname("circle"),i,r);}
}
py++;
color(3);put(chrname("heart"),px,py);
if(py>=15 && (px-x)<=3 && (px-x)>=0){py=0;px=Math.floor(Math.random()*17)+1;sc++;beep(0);}
else{if(py>=15){cleartimer();}}
var r1=Math.floor(Math.random()*3);
if(r1==0 && x>1){x--;m1[x+4]=0;m1[x]=1;}
if(r1==1 && x<15){x++;m1[x-1]=0;m1[x+3]=1;}
}
function keyin(keycode){
if(keycode=="left" && x>1){x--;m1[x+4]=0;m1[x]=1;}
if(keycode=="right" && x<15){x++;m1[x-1]=0;m1[x+3]=1;}
} 
function routine(){
draw();
color(7);
put(chrs,3,19);
put(chrc,4,19);
put(chro,5,19);
put(chrr,6,19);
put(chre,7,19);
color(7);
putscore();
beep(1);
}
function putscore(){

var cursc,modsc;
modsc=sc%10;
putnumchr(modsc,11,19);
cursc=Math.floor(sc/10);
modsc=cursc%10;
putnumchr(modsc,10,19);
cursc=Math.floor(cursc/10);
modsc=cursc%10;
putnumchr(modsc,9,19);
}
function putnumchr(num,x,y){
if(num==0){put(chrnum0,x,y);}
if(num==1){put(chrnum1,x,y);}
if(num==2){put(chrnum2,x,y);}
if(num==3){put(chrnum3,x,y);}
if(num==4){put(chrnum4,x,y);}
if(num==5){put(chrnum5,x,y);}
if(num==6){put(chrnum6,x,y);}
if(num==7){put(chrnum7,x,y);}
if(num==8){put(chrnum8,x,y);}
if(num==9){put(chrnum9,x,y);}
}