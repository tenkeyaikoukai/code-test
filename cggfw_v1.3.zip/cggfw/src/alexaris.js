var lifemtx=new Array();
var lifemtx2=new Array();

var chr1=new Array(
0,0,1,1,1,1,0,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,1,0,0,0,0,1,0,
0,0,1,1,1,1,0,0
);
var chr2=new Array(
0,0,1,0,0,1,0,0,
0,1,1,1,1,1,1,0,
0,1,1,1,1,1,1,0,
0,0,1,1,1,1,0,0,
0,0,0,1,1,0,0,0
);
var chr3=new Array(
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
);
var chr4=new Array(
1,0,0,0,0,0,0,0,
1,1,1,0,0,0,0,0,
1,1,1,1,1,0,0,0,
1,1,1,1,1,1,1,0,
1,1,1,1,1,1,1,1
);

var chr5=new Array(
0,0,0,0,0,0,0,1,
0,0,0,0,0,1,1,1,
0,0,0,1,1,1,1,1,
0,1,1,1,1,1,1,1,
1,1,1,1,1,1,1,1
);
var chr6=new Array(
0,0,0,0,0,0,0,0,
0,0,1,1,0,0,0,0,
1,1,0,0,1,1,0,0,
0,0,0,0,0,0,1,1,
0,0,0,0,0,0,0,0
);
var chr7=new Array(
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,1,1,1,1,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0
);
var chr8=new Array(
0,0,1,0,0,1,0,0,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0
);

//my ship

var pcg1=new Array(
0,0,0,1,1,0,0,0,
0,0,1,0,0,1,0,0,
0,0,0,1,1,0,0,0,
0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,0,0,
0,1,1,0,0,1,1,0,
1,1,1,1,1,1,1,1,
0,0,1,0,0,1,0,0
);

//power coin

var pcg2=new Array(
0,0,1,1,1,1,0,0,
0,1,0,0,0,0,1,0,
1,0,1,1,1,0,0,1,
1,0,1,0,0,1,0,1,
1,0,1,0,0,1,0,1,
1,0,1,1,1,0,0,1,
1,0,1,0,0,0,0,1,
1,0,1,0,0,0,0,1,
0,1,0,0,0,0,1,0,
0,0,1,1,1,1,0,0
);

//jetta �O�i�i�ˌ��j�ˌ���

var pcg3=new Array(
0,0,0,0,0,0,0,0,
1,0,0,0,0,0,0,1,
1,1,0,1,1,0,1,1,
1,1,1,1,1,1,1,1,
1,0,1,1,0,1,1,1,
1,0,1,1,0,1,1,1,
1,0,1,1,0,1,1,1,
1,0,0,1,1,0,1,1,
0,1,0,0,0,1,1,0,
0,0,1,1,1,1,0,0
);

//gona�i�g���b�L�[�A�͂݁j�V����

var pcg4=new Array(
0,0,0,0,0,0,0,0,
0,0,0,1,1,0,0,0,
0,0,1,0,1,1,0,0,
0,1,1,0,1,1,1,0,
1,1,1,1,1,1,1,1,
1,0,0,0,1,0,0,1,
0,1,0,0,1,1,1,0,
0,0,1,0,1,1,0,0,
0,0,0,1,1,0,0,0,
0,0,0,0,0,0,0,0
);

//sphera�i�t�H�[���[�V�����j�L�@�ґ�

var pcg5=new Array(
0,0,1,1,1,1,0,0,
0,1,0,1,0,1,1,0,
1,1,1,1,1,0,1,1,
1,0,1,1,1,1,1,1,
1,1,1,1,1,0,1,1,
1,0,1,0,1,1,1,1,
1,0,1,1,1,1,0,1,
1,1,0,1,1,0,1,1,
0,1,1,0,0,1,1,0,
0,0,1,1,1,1,0,0
);

//forest

var pcg6=new Array(
0,0,1,1,1,1,0,0,
0,1,0,1,0,1,1,0,
1,0,1,1,1,0,1,1,
0,0,1,1,0,1,1,1,
0,1,0,1,1,0,1,0,
1,0,1,0,1,0,1,1,
1,0,1,1,1,1,0,0,
1,1,0,0,1,0,1,1,
0,1,1,0,0,1,0,0,
0,0,1,1,1,0,0,0
);

//city

var pcg7=new Array(
0,0,0,0,0,0,0,0,
0,1,1,1,1,1,1,0,
0,1,0,1,0,1,1,0,
0,1,0,1,1,0,1,0,
0,1,0,1,1,0,1,0,
0,1,0,1,1,0,1,0,
0,1,0,1,1,1,1,0,
0,1,0,0,0,0,1,0,
0,1,1,1,1,1,1,0,
0,0,0,0,0,0,0,0
);

var m=new Array();
var m2=new Array();
var curx=20;
var cury=80;
var mc,sc,x,y,k,f,i,j,lp,r,l,counter,getcounter,chaincounter,chainflag,lnum;
var clck=new Audio("pingpong1.mp3")
var beep=new Audio("beep.mp3");
var num=50;//�G�o���p�x�F�������ق��������Bdefault=30

var chrctx=new Array(0,8,10);
function init(){

makelife();

play();

}
function play(){
for(i = 0 ;i<= 9 ;i++){
for( j = 0 ; j<=19 ;j++){
m[i*20+j] = 0;
}
} 
for ( i = 0 ; i<= 19 ;i++){
r = Math.floor(Math.random() * 10) + 1;
if ( r == 1 ) { m[1*20 +i] = 1;}
else { m[i*20+ 1] = 0;}
}
sc = 0 ;
x = 10;
y = 8;
counter=0;
chaincounter=0;
chainflag=0;
k=1;
m[y*20+x] = 3;
draw();
sc = sc + 1;


draw();


}
function next(){

draw();

}
function draw(){

ctx.fillStyle="rgb(0,0,0)";
ctx.fillRect(0,0,640,400);
ctx.fillStyle="rgb(255,255,0)";
for ( i =0 ; i<= 9 ;i++){
for ( j = 0 ; j<=19 ; j++){
if(lifemtx[((Math.floor(sc/8)-i)%100)*20+j]==1){ctx.fillStyle="rgb(0,100,0)";put(pcg6,chrctx,j*8,i*10+(sc%8)-1);}
if(lifemtx[((Math.floor(sc/8)-i)%100)*20+j]==2){ctx.fillStyle="rgb(100,100,100)";put(pcg7,chrctx,j*8,i*10+(sc%8)-1);}

if(m[i*20+j]==1 && sc<100){ctx.fillStyle="rgb(255,0,0)";put(pcg3,chrctx,j*8,i*10);}
if(m[i*20+j]==1 &&(sc>=100 && sc<200)){ctx.fillStyle="rgb(255,0,0)";put(pcg4,chrctx,j*8,i*10);}
if(m[i*20+j]==1 && sc>=200){ctx.fillStyle="rgb(255,0,0)";put(pcg5,chrctx,j*8,i*10);}
if(m[i*20+j]==2){ctx.fillStyle="rgb(255,255,0)";put(pcg2,chrctx,j*8,i*10);}
if(m[i*20+j]==3){ctx.fillStyle="rgb(255,255,255)";put(pcg1,chrctx,j*8,i*10);}
}
}

}
function keyin(){
if ( event.keyCode == 37 & x >= 1 ) { x = x - 1 ;}
if ( event.keyCode == 39 & x < 19 ){ x = x + 1 ;}
}
function schroll(){
clck.play();
for ( i = 0 ; i<= 19 ; i++){
 r = Math.floor(Math.random() * num + 1);
 if ( r == 1 ){ m[1*20+i] = 1;} else {m[1*20+i] = 0;}
}
if (counter==20){
 r = Math.floor(Math.random() * 20);
m[1*20+r] = 2;}
for (i=8 ; i>=0 ;i--){
 for (j = 0 ;j<=19 ;j++){
  m[(i+1)*20+j] = m[i*20+j];
 }
}  
if (m[y*20+x] == 1){clearInterval(ti);disp.innerHTML="GAME OVER";mssg.innerHTML="";}
if (m[y*20+x]==2 & chaincounter<=1){mssg.innerHTML="GET!";sc=sc+100;counter=0;chainflag=1;chaincounter=chaincounter+1;beep.play();}
if (m[y*20+x]==2 & chaincounter>=2){mssg.innerHTML=chaincounter+" chain!";sc=sc+100*chaincounter;chainflag=1;chaincounter=chaincounter+1;counter=0;beep.play();}
if(m[y*20+x]!=1 & m[y*20+x]!=2){
m[y*20+x] = 3;
draw(); 
sc=sc+1;
counter=counter+1;
disp.innerHTML="SCORE "+sc;
if(counter==25 & chainflag==0){chaincounter=0;counter=0;}
if(counter==25 & chainflag==1){chainflag=0;counter=0;}
}

}
function routine(){
schroll();

}

function makelife(){

for(i = 0 ;i<= 99 ;i++){
for( j = 0 ; j<=19 ;j++){
lifemtx[i*20+j] = 0;
}
} 
for(i = 0 ;i<= 99 ;i++){
for( j = 0 ; j<=19 ;j++){
lifemtx2[i*20+j] = 0;
}
} 

for (i=0;i<=99;i++){
for ( j = 0 ; j<= 19 ;j++){
r = Math.floor(Math.random() * 3) + 1;
if ( r == 1 ) { lifemtx[i*20 +j] = 1;}
else { lifemtx[i*20+ j] = 0;}
}
}

for(lp=0;lp<=20;lp++){

for (i=0;i<=99;i++){
for (j=0;j<=19;j++){
lnum=0;
if(lifemtx[(i-1)*20+j-1]==1){lnum=lnum+1;}
if(lifemtx[(i-1)*20+j]==1){lnum=lnum+1;}
if(lifemtx[(i-1)*20+j+1]==1){lnum=lnum+1;}
if(lifemtx[i*20+j-1]==1){lnum=lnum+1;}
if(lifemtx[i*20+j+1]==1){lnum=lnum+1;}
if(lifemtx[(i+1)*20+j-1]==1){lnum=lnum+1;}
if(lifemtx[(i+1)*20+j]==1){lnum=lnum+1;}
if(lifemtx[(i+1)*20+j+1]==1){lnum=lnum+1;}
if(lifemtx[i*20+j]==1 & lnum<2){lifemtx2[i*20+j]=0;}
if(lifemtx[i*20+j]==1 & lnum>3){lifemtx2[i*20+j]=2;}
if(lifemtx[i*20+j]!=1 & lnum==3){lifemtx2[i*20+j]=1;}
if(lifemtx[i*20+j]!=1 & lnum!=3){lifemtx2[i*20+j]=0;}
}
}
for (i=0;i<=99;i++){
for (j=0;j<=19;j++){
lifemtx[i*20+j]=lifemtx2[i*20+j];
}
}

}


}
