var m=new Array();
var curx=20;
var cury=80;
var x=20;
var y=20;
var bx=5;
var by=16;
var num,r;
function init(){
var i,j,r;
for(i=0;i<=19;i++){
for(j=0;j<=19;j++){
r=Math.floor(Math.random()*5+1);
if(r==1 && i>=1 && i<=18 && j>=1 && j<=18){m[i*20+j]=1;}else{m[i*20+j]=0;}
}
}
play();

}
function play(){

draw();

}
function next(){

draw();

}
function draw(){

cls();
for ( i =0 ; i<= y-1 ;i++){
for ( j = 0 ; j<=x-1 ; j++){
if(m[i*x+j]==1){color(2);put(chrname("brick"),j,i);}
}
}
   color(7);
   put(chrname("circle"),bx,by);

}
  function keyin(keychr){

      if(keychr==="right" & bx<19){
   if(m[by*x+bx+1]==1 && m[by*x+bx+2]==1 || m[by*x+bx+1]==1 && bx>17){
  document.getElementById("msgwin").innerHTML="You can not go this direction";
   }
   if(m[by*x+bx+1]==1 && m[by*x+bx+2]==0 && bx<=17){
  bx++;m[by*x+bx]=0;m[by*x+bx+1]=1;draw();
   }
   if(m[by*x+bx+1]==0){bx++;draw();}

}

     if(keychr=="left" & bx>0){
   if(m[by*x+bx-1]==1 && m[by*x+bx-2]==1 || m[by*x+bx-1]==1 && bx<3){
  document.getElementById("msgwin").innerHTML="You can not go this direction";
   }
   if(m[by*x+bx-1]==1 && m[by*x+bx-2]==0 && bx>=3){
  bx--;m[by*x+bx]=0;m[by*x+bx-1]=1;draw();
   }
   if(m[by*x+bx-1]==0){bx--;draw();}
}

     if(keychr=="down" & by<19){
   if(m[(by+1)*x+bx]==1 && m[(by+2)*x+bx]==1 || m[(by+1)*x+bx]==1 && by>17){
  document.getElementById("msgwin").innerHTML="You can not go this direction";
   }
   if(m[(by+1)*x+bx]==1 && m[(by+2)*x+bx]==0 && by<=17){
  by++;m[by*x+bx]=0;m[(by+1)*x+bx]=1;draw();
   }
   if(m[(by+1)*x+bx]==0){by++;draw();}
}

     if(keychr=="up" & by>0){
   if(m[(by-1)*x+bx]==1 && m[(by-2)*x+bx]==1 || m[(by-1)*x+bx]==1 && by<3){
  document.getElementById("msgwin").innerHTML="You can not go this direction";
   }
   if(m[(by-1)*x+bx]==1 && m[(by-2)*x+bx]==0 && by>=3){
  by--;m[by*x+bx]=0;m[(by-1)*x+bx]=1;draw();
   }
   if(m[(by-1)*x+bx]==0){by--;draw();}
}


  } 
 
function routine(){
}
