


function init(){
settimer(1000);
}

function routine(){
var r1,r2,r3;
cls();
for(i=1;i<=20;i++){
r1=Math.floor(Math.random()*20);
r2=Math.floor(Math.random()*20);
r3=Math.floor(Math.random()*7)+1;
color(r3);
put(chrname("star"),r1,r2);
}
}
