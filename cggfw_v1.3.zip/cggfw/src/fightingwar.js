


var myx=1;
var myy=6;
var px=18;
var py=6;
var tx=7;
var ty=17;
var bf=false;
var bx,by;
var sc=0;
function init(){

color(7);
put(chrs,1,19);
put(chrc,2,19);
put(chro,3,19);
put(chrr,4,19);
put(chre,5,19);
color(7);
putscore();

for(i=0;i<=19;i++){
color(4);
put(chrname("fill"),i,18);
}
color(7);
put(chrname("sw"),myx,myy);
color(2);
put(chrname("se"),px,py);
color(1);
put(chrname("fill"),tx,ty);

}
function keyin(keycode){
if(keycode=="left" && myx>=1){myx--;}
if(keycode=="right" && myx<=18){myx++;}
if(keycode=="up" && myy>=3){myy--;}
if(keycode=="down" && myy<=6){myy++;}
if(keycode=="z" && !bf){bf=true;bx=myx;by=myy;}
if(px==myx && py==myy){claertimer();} 
}
function routine(){
cls();
color(7);
put(chrs,1,19);
put(chrc,2,19);
put(chro,3,19);
put(chrr,4,19);
put(chre,5,19);
color(7);
putscore();

for(i=0;i<=19;i++){
color(4);
put(chrname("fill"),i,18);
}
color(7);
put(chrname("sw"),myx,myy);
color(2);
put(chrname("se"),px,py);
color(1);
put(chrname("fill"),tx,ty);

px--;
if(px<=0){px=19;}
var r;
r=Math.floor(Math.random()*3);
if(r==1 && py>=3){py--;}
if(r==2 && py<=6){py++;}
if(px==myx && py==myy){cleartimer();}
r=Math.floor(Math.random()*3);
if(r==1 && tx>=1){tx--;}
if(r==2 && tx<=18){tx++;}
if(bf){by++;color(6);put(chrname("circle"),bx,by);}
if(bx==tx && by==ty){sc++;}
if(by>=17){bf=false;by=0;}
}
function putscore(){
var cursc,modsc;
modsc=sc%10;
putnumchr(modsc,9,19);
cursc=Math.floor(sc/10);
modsc=cursc%10;
putnumchr(modsc,8,19);
cursc=Math.floor(cursc/10);
modsc=cursc%10;
putnumchr(modsc,7,19);
}
function putnumchr(num,x,y){
if(num==0){put(chrnum0,x,y);}
if(num==1){put(chrnum1,x,y);}
if(num==2){put(chrnum2,x,y);}
if(num==3){put(chrnum3,x,y);}
if(num==4){put(chrnum4,x,y);}
if(num==5){put(chrnum5,x,y);}
if(num==6){put(chrnum6,x,y);}
if(num==7){put(chrnum7,x,y);}
if(num==8){put(chrnum8,x,y);}
if(num==9){put(chrnum9,x,y);}
}