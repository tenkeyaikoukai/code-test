


function init(){

color(7);
put(chrs,1,19);
put(chrc,2,19);
put(chro,3,19);
put(chrr,4,19);
put(chre,5,19);
color(7);
//put(chrnum4,6,19);
put(chrnum6,7,19);
put(chrnum5,8,19);
put(chrnum5,9,19);
put(chrnum3,10,19);
put(chrnum5,11,19);
//put(chrr,12,19);
color(5);
put(chrr,13,19);
put(chre,14,19);
put(chrs,15,19);
put(chrt,16,19);

put(chrname("heart"),18,19);
put(chrname("heart"),19,19);


}

function routine(){

}
