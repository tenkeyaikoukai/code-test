
var clck=new Audio("audio/pingpong1.mp3");
var beep=new Audio("audio/beep.mp3");
var pxmtx=new Array(4,9,14);
var rn=0;
var py=11;
var px=pxmtx[2];
var mx=2;
var sc=0;
function init(){

puttrees();
settimer(500);

}
function puttree(x,y){
color(4);
put(chr5,x+1,y);
put(chr3,x+2,y);
put(chr4,x+3,y);
put(chr5,x+1,y+1);
put(chr3,x+2,y+1);
put(chr4,x+3,y+1);
put(chr5,x,y+2);
put(chr3,x+1,y+2);
put(chr3,x+2,y+2);
put(chr3,x+3,y+2);
put(chr4,x+4,y+2);
color(2);
put(chr3,x+2,y+3);
put(chr3,x+2,y+4);
put(chr3,x+2,y+5);
put(chr3,x+2,y+6);
}
function routine(){
cls();
puttrees();
color(3);
clck.play();
py+=1;
if(py>=15 && px==pxmtx[mx]){beep.play();px=pxmtx[Math.floor(Math.random()*3)];py=11;sc++;} 
else{if(py>=15){cleartimer();}}
if(py<=14){put(chr2,px,py);}else{put(chr2,px,17);}
color(6);put(chrv,pxmtx[mx],15);
color(7);
put(chrs,3,19);
put(chrc,4,19);
put(chro,5,19);
put(chrr,6,19);
put(chre,7,19);
color(7);
putscore();

}
function keyin(keychr){
color(0);put(chr3,pxmtx[mx],15);
if(keychr=="left" && mx>=1){mx--;}
if(keychr=="right" && mx<=1){mx++;}
color(6);put(chrv,pxmtx[mx],15);

}
function putscore(){

var cursc,modsc;
modsc=sc%10;
putnumchr(modsc,11,19);
cursc=Math.floor(sc/10);
modsc=cursc%10;
putnumchr(modsc,10,19);
cursc=Math.floor(cursc/10);
modsc=cursc%10;
putnumchr(modsc,9,19);
}
function putnumchr(num,x,y){
if(num==0){put(chrnum0,x,y);}
if(num==1){put(chrnum1,x,y);}
if(num==2){put(chrnum2,x,y);}
if(num==3){put(chrnum3,x,y);}
if(num==4){put(chrnum4,x,y);}
if(num==5){put(chrnum5,x,y);}
if(num==6){put(chrnum6,x,y);}
if(num==7){put(chrnum7,x,y);}
if(num==8){put(chrnum8,x,y);}
if(num==9){put(chrnum9,x,y);}
}
function puttrees(){
var x=3;
var y=8;
puttree(x,y);
x=8;
puttree(x,y);
x=13;
puttree(x,y);

}
